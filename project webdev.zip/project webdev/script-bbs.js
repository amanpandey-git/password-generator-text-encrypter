function generatePassword() {
  const lengthInput = document.getElementById("passLength");
  let length = parseInt(lengthInput.value);
  if (isNaN(length) || length < 4) length = 16;
  if (length > 64) length = 64;

  // Blum Blum Shub parameters
  const p = 499; // prime, 3 mod 4
  const q = 547; // prime, 3 mod 4
  const M = p * q;

  // Seed: use current time mod M and ensure it's odd and co-prime to M
  let seed = Date.now() % M;
  if (seed % 2 === 0) seed += 1;

  let x = (seed * seed) % M;

  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+";
  let password = "";

  for (let i = 0; i < length; i++) {
    x = (x * x) % M;
    const rand = x % chars.length;
    password += chars.charAt(rand);
  }

  document.getElementById("output").value = password;
}

function copyToClipboard(elementId) {
  const text = document.getElementById(elementId).value;
  if (!text) return alert("Nothing to copy!");
  navigator.clipboard.writeText(text).then(() => {
    alert("Copied to clipboard!");
  }, () => {
    alert("Failed to copy!");
  });
}
