function processText() {
  const inputText = document.getElementById('inputText').value;
  let shift = parseInt(document.getElementById('shift').value);
  const operation = document.querySelector('input[name="operation"]:checked').value;

  if (!inputText) {
    alert("Please enter some text.");
    return;
  }
  if (isNaN(shift) || shift < 1 || shift > 25) {
    alert("Please enter a valid shift between 1 and 25.");
    return;
  }

  if (operation === 'decrypt') {
    shift = 26 - shift;
  }

  let result = "";

  for (let char of inputText) {
    let code = char.charCodeAt(0);

    if (code >= 65 && code <= 90) { // Uppercase A-Z
      result += String.fromCharCode(((code - 65 + shift) % 26) + 65);
    } else if (code >= 97 && code <= 122) { // Lowercase a-z
      result += String.fromCharCode(((code - 97 + shift) % 26) + 97);
    } else {
      // Non-alphabetic characters remain unchanged
      result += char;
    }
  }

  document.getElementById('output').value = result;
}

function copyToClipboard(elementId) {
  const text = document.getElementById(elementId).value;
  if (!text) return alert("Nothing to copy!");
  navigator.clipboard.writeText(text).then(() => {
    alert("Copied to clipboard!");
  }, () => {
    alert("Failed to copy!");
  });
}
