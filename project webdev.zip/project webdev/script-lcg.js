function generatePassword() {
  let length = parseInt(document.getElementById("passLength").value);
  if (isNaN(length) || length < 4) length = 16;
  if (length > 64) length = 64;

  // LCG parameters: modulus, multiplier, increment
  const modulus = 2 ** 31;
  const multiplier = 1103515245;
  const increment = 12345;

  // Seed from current time
  let seed = Date.now() % modulus;

  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+";
  let password = "";

  for (let i = 0; i < length; i++) {
    seed = (multiplier * seed + increment) % modulus;
    const rand = seed % chars.length;
    password += chars.charAt(rand);
  }

  document.getElementById("output").value = password;
}

function copyToClipboard(elementId) {
  const text = document.getElementById(elementId).value;
  if (!text) return alert("Nothing to copy!");
  navigator.clipboard.writeText(text).then(() => {
    alert("Copied to clipboard!");
  }, () => {
    alert("Failed to copy!");
  });
}
