// Helper: Sanitize to uppercase letters only
function sanitizeText(text) {
  return text.toUpperCase().replace(/[^A-Z]/g, '');
}

function processText() {
  const inputText = document.getElementById('inputText').value;
  const keyInput = document.getElementById('key').value;
  const operation = document.querySelector('input[name="operation"]:checked').value;

  if (!inputText || !keyInput.match(/^[A-Za-z]+$/)) {
    alert("Please enter valid text and key (letters only).");
    return;
  }

  const text = sanitizeText(inputText);
  const key = sanitizeText(keyInput);

  if (key.length === 0) {
    alert("Key must contain at least one letter.");
    return;
  }

  let result = '';

  // Vigenère cipher logic on uppercase letters A-Z
  for (let i = 0, j = 0; i < text.length; i++) {
    let c = text.charCodeAt(i) - 65; // A=0
    let k = key.charCodeAt(j % key.length) - 65;
    let val;

    if (operation === 'encrypt') {
      val = (c + k) % 26;
    } else { // decrypt
      val = (c - k + 26) % 26;
    }

    result += String.fromCharCode(val + 65);
    j++;
  }

  document.getElementById('output').value = result;
}

function copyToClipboard(elementId) {
  const text = document.getElementById(elementId).value;
  if (!text) return alert("Nothing to copy!");
  navigator.clipboard.writeText(text).then(() => {
    alert("Copied to clipboard!");
  }, () => {
    alert("Failed to copy!");
  });
}
